import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.*;

public class DelphiInterpreter extends delphiBaseVisitor<Object>{

    public static Map<String, DelphiClass> classes = new HashMap<>();
    private static Map<String, Object> variables = new HashMap<>();

    private static Map<String, DelphiObject> objects = new HashMap<>();

    public enum AccessIdentifiers {
        PUBLISHED("published"),
        PRIVATE("private"),
        PUBLIC("public"),
        STRICT("strict"),
        PROTECTED("protected");

        private final String name;

        AccessIdentifiers(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }

        public static AccessIdentifiers fromString(String name) {
            for (AccessIdentifiers identifier : AccessIdentifiers.values()) {
                if (identifier.name.equalsIgnoreCase(name)) {
                    return identifier;
                }
            }
            throw new IllegalArgumentException("No constant with name " + name + " found");
        }
    }
    public enum DataTypes {
        STRING("string"),
        INTEGER("integer"),
        REAL("real"),
        BOOLEAN("boolean"),
        OBJECT("object");

        private final String name;

        DataTypes(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }

        public static DataTypes fromString(String name) {
            for (DataTypes type : DataTypes.values()) {
                if (type.name.equalsIgnoreCase(name)) {
                    return type;
                }
            }
            throw new IllegalArgumentException("No constant with name " + name + " found");
        }
    }


    private static class VariableObject {
        String className;
        String name;
        DataTypes datatype;
        AccessIdentifiers visibility;
        Object value;

        public VariableObject(String name, DataTypes datatype, AccessIdentifiers visibility, Object value) {
            this.name = name;
            this.datatype = datatype;
            this.visibility = visibility;
            if(value == null) {
                switch (this.datatype) {
                    case DataTypes.STRING -> this.value = "";
                    case DataTypes.BOOLEAN -> this.value = false;
                    case DataTypes.INTEGER -> this.value = 0;
                    case DataTypes.REAL -> this.value = 0.0;
                    default -> this.value = null;
                }
            } else {
                this.value = value;
            }
        }
    }

    @Override
    public Object visitProgramHeading(delphiParser.ProgramHeadingContext ctx) {
        return super.visitProgramHeading(ctx);
    }

    private static class ConstructorObject {
        String name;
        Map<String, VariableObject> parameters = new HashMap<String, VariableObject>();

        AccessIdentifiers visibility;

        List<List<String>> statements = new ArrayList<>();
    }

    private static class DestructorObject {
        String name;
        Map<String, VariableObject> parameters = new HashMap<String, VariableObject>();

        AccessIdentifiers visibility;

        List<List<String>> statements = new ArrayList<>();
    }

    private static class ProcedureObject {
        String name;
        Map<String, VariableObject> variables = new HashMap<String, VariableObject>();
        AccessIdentifiers visibility;
        List<List<String>> statements = new ArrayList<>();
    }

    private static class DelphiClass {
        String name;
        Map<String, VariableObject> variables = new HashMap<>();
        Map<String, ConstructorObject> constructors = new HashMap<>();
        Map<String, DestructorObject> destructors = new HashMap<>();
        Map<String, ProcedureObject> procedures = new HashMap<>();

        public DelphiClass(String name) {
            this.name = name;
        }
    }

    private static class DelphiObject {
        DelphiClass delphiClass;
        Map<String, Object> instanceVariables = new HashMap<>();

        DelphiObject(DelphiClass delphiClass) {
            this.delphiClass = delphiClass;
            this.instanceVariables.putAll(this.delphiClass.variables);
        }

    }

    @Override
    public Object visitProgram(delphiParser.ProgramContext ctx) {
        return super.visitProgram(ctx);
    }

    @Override
    public Object visitBlock(delphiParser.BlockContext ctx) {
        // Process type definitions (classes)
        if (ctx.typeDefinitionPart() != null) {
            ctx.typeDefinitionPart().forEach(this::visit);
        }

        if (ctx.variableDeclarationPart() != null) { // Process variable declarations
            ctx.variableDeclarationPart().forEach(this::visit);
        }

        if (ctx.procedureAndFunctionDeclarationPart() != null) {
            ctx.procedureAndFunctionDeclarationPart().forEach(this::visit);
        }

        if(ctx.constructorDeclarationPart() != null) {
            ctx.constructorDeclarationPart().forEach(this::visit);
        }

        if(ctx.destructorDeclarationPart() != null) {
            ctx.destructorDeclarationPart().forEach(this::visit);
        }

        // Execute the compound statement
        return visit(ctx.compoundStatement());
    }

    @Override
    public Object visitTypeDefinition(delphiParser.TypeDefinitionContext ctx) {
        if (ctx.classType() != null) {
            String className = ctx.identifier().getText();
//            System.out.println("CLASS NAME: " + className);
            DelphiClass newClass = new DelphiClass(className);
            classes.put(className, newClass);

            // Process class body
            visitClassBlock(ctx.classType().classBlock(), newClass);
//            System.out.println("CLASS ENDS");
        }
        return null;
    }

    private void visitClassBlock(delphiParser.ClassBlockContext ctx, DelphiClass currentClass) {
        // extract visibility section
        for (delphiParser.VisibilitySectionContext section : ctx.visibilitySection()) {
//            System.out.println("Visibility section STARTS");
//            System.out.println("Visibility keyword: " + section.visibilityKeyword().getText());// returns public, private, etc
            AccessIdentifiers accessIdentifiers = AccessIdentifiers.fromString(section.visibilityKeyword().getText());
            for (delphiParser.ClassMemberContext member : section.classMember()) {
                if (member.variableDeclaration() != null && member.variableDeclaration().identifierList() != null && member.variableDeclaration().identifierList().identifier() != null) {
                    for (delphiParser.IdentifierContext id : member.variableDeclaration().identifierList().identifier()) {
//                        System.out.println("Variable name: " + id.getText()); // a, b
                        VariableObject variable = new VariableObject(id.getText(),
                                DataTypes.fromString(member.variableDeclaration().type_().simpleType().typeIdentifier().getText()),
                                accessIdentifiers,
                                null);
                        currentClass.variables.put(id.getText(), variable);
                    }
//                    System.out.println("Variable type: " + member.variableDeclaration().type_().simpleType().typeIdentifier().getText());// integer
                } else if(member.constructorDefinition() != null) { // list of constructors
//                    System.out.println("Constructor name: " + member.constructorDeclaration().identifier().getText());// Create -> constructor name
                    String constructorName = member.constructorDefinition().identifier().getText();
                    ConstructorObject constructor = new ConstructorObject();
                    constructor.name = constructorName;
                    constructor.visibility = accessIdentifiers;
                    if(member.constructorDefinition().formalParameterList() != null) {
                        for( delphiParser.FormalParameterSectionContext parameters: member.constructorDefinition().formalParameterList().formalParameterSection()) {
                            for (delphiParser.IdentifierContext id : parameters.parameterGroup().identifierList().identifier()) {
//                            System.out.println("Constructor parameter: " + id.getText());// x, y -> parameters of constructor
                                VariableObject variable = new VariableObject(
                                        id.getText(),
                                        DataTypes.fromString(parameters.parameterGroup().typeIdentifier().getText()),
                                        accessIdentifiers,
                                        null
                                );
                                constructor.parameters.put(id.getText(), variable);
                            }
//                        System.out.println("Constructor parameter datatype: " + parameters.parameterGroup().typeIdentifier().getText());// integer -> data type of parameters of constructor

                        }
                    }
                    currentClass.constructors.put(constructorName, constructor);
                } else if(member.destructorDefinition() != null) { // list of denstructors
                    String destructorName = member.destructorDefinition().identifier().getText();
                    DestructorObject destructor = new DestructorObject();
                    destructor.name = destructorName;
                    destructor.visibility = accessIdentifiers;
                    if(member.destructorDefinition().formalParameterList() != null) {
                        for( delphiParser.FormalParameterSectionContext parameters: member.destructorDefinition().formalParameterList().formalParameterSection()) {
                            for (delphiParser.IdentifierContext id : parameters.parameterGroup().identifierList().identifier()) {
//                            System.out.println("Constructor parameter: " + id.getText());// x, y -> parameters of constructor
                                VariableObject variable = new VariableObject(
                                        id.getText(),
                                        DataTypes.fromString(parameters.parameterGroup().typeIdentifier().getText()),
                                        accessIdentifiers,
                                        null
                                );
                                destructor.parameters.put(id.getText(), variable);
                            }
//                        System.out.println("Constructor parameter datatype: " + parameters.parameterGroup().typeIdentifier().getText());// integer -> data type of parameters of constructor

                        }
                    }
                    currentClass.destructors.put(destructorName, destructor);
                } else if(member.methodDeclaration() != null) { // list of procedures
//                    System.out.println("Procedure name: " + member.methodDeclaration().identifier().getText()); // Add -> procedure name
                    String methodName = member.methodDeclaration().identifier().getText();
                    ProcedureObject procedure = new ProcedureObject();
                    procedure.name = methodName;
                    procedure.visibility = accessIdentifiers;
                    if(member.methodDeclaration().formalParameterList() != null) {
                        for( delphiParser.FormalParameterSectionContext parameters: member.methodDeclaration().formalParameterList().formalParameterSection()) {
                            for (delphiParser.IdentifierContext id : parameters.parameterGroup().identifierList().identifier()) {
//                            System.out.println("Procedure parameter: " + id.getText());// a -> parameters of procedure
                                VariableObject variable = new VariableObject(
                                        id.getText(),
                                        DataTypes.fromString(parameters.parameterGroup().typeIdentifier().getText()),
                                        accessIdentifiers,
                                        null
                                );
                                procedure.variables.put(id.getText(), variable);
                            }
//                        System.out.println("Procedure parameter datatype: " + parameters.parameterGroup().typeIdentifier().getText());// integer -> data type of parameters of procedure
                        }
                    }
                    currentClass.procedures.put(methodName, procedure);
                }
            }
//            System.out.println("Visibility section ENDS");
        }
    }

    @Override
    public Object visitConstructorDeclarationPart(delphiParser.ConstructorDeclarationPartContext ctx) {

        String constructorName = ctx.constructorDeclaration().identifier().getText();
        String[] constructorNames = constructorName.split("\\.");

        DelphiClass delphiClass = classes.get(constructorNames[0]);
        ConstructorObject constructorObject = delphiClass.constructors.get(constructorNames[1]);

        delphiParser.StatementsContext statements = ctx.constructorDeclaration().block().compoundStatement().statements();
        if (statements != null) {
            statements.statement().forEach(statementContext -> {
                delphiParser.SimpleStatementContext simpleStatementContext = statementContext.unlabelledStatement().simpleStatement();
                if (simpleStatementContext.assignmentStatement() != null) {
                    String variable = simpleStatementContext.assignmentStatement().variable().identifier().get(0).getText();
                    String expression = simpleStatementContext.assignmentStatement().expression().simpleExpression().term().signedFactor().factor().variable().identifier().get(0).getText();
                    ArrayList<String> statementList = new ArrayList<>();
                    statementList.add("ASSIGNMENT");
                    statementList.add(variable);
                    statementList.add(expression);
                    constructorObject.statements.add(statementList);
                } else if (simpleStatementContext.procedureStatement() != null) {
                    if (Objects.equals(simpleStatementContext.procedureStatement().identifier().getText(), "Writeln")) {
                        ArrayList<String> statementList = new ArrayList<>();
                        statementList.add("PRINT");
                        statementList.add(simpleStatementContext.procedureStatement().parameterList().actualParameter().get(0).expression().simpleExpression().term().signedFactor().factor().unsignedConstant().string().getText());
                        constructorObject.statements.add(statementList);
                    }
                }
            });
        }

        return super.visitConstructorDeclarationPart(ctx);
    }

    @Override
    public Object visitDestructorDeclarationPart(delphiParser.DestructorDeclarationPartContext ctx) {

        String destructorName = ctx.destructorDeclaration().identifier().getText();
        String[] destructorNames = destructorName.split("\\.");

        DelphiClass delphiClass = classes.get(destructorNames[0]);
        DestructorObject destructorObject = delphiClass.destructors.get(destructorNames[1]);

        delphiParser.StatementsContext statements = ctx.destructorDeclaration().block().compoundStatement().statements();
        if (statements != null) {
            statements.statement().forEach(statementContext -> {
                delphiParser.SimpleStatementContext simpleStatementContext = statementContext.unlabelledStatement().simpleStatement();
                if (simpleStatementContext.assignmentStatement() != null) {
                    String variable = simpleStatementContext.assignmentStatement().variable().identifier().get(0).getText();
                    String expression = simpleStatementContext.assignmentStatement().expression().simpleExpression().term().signedFactor().factor().variable().identifier().get(0).getText();
                    ArrayList<String> statementList = new ArrayList<>();
                    statementList.add("ASSIGNMENT");
                    statementList.add(variable);
                    statementList.add(expression);
                    destructorObject.statements.add(statementList);
                } else if (simpleStatementContext.procedureStatement() != null) {
                    if (Objects.equals(simpleStatementContext.procedureStatement().identifier().getText(), "Writeln")) {
                        ArrayList<String> statementList = new ArrayList<>();
                        statementList.add("PRINT");
                        statementList.add(simpleStatementContext.procedureStatement().parameterList().actualParameter().get(0).expression().simpleExpression().term().signedFactor().factor().unsignedConstant().string().getText());
                        destructorObject.statements.add(statementList);
                    }
                }
            });
        }

        return super.visitDestructorDeclarationPart(ctx);
    }

        @Override
    public Object visitProcedureAndFunctionDeclarationPart(delphiParser.ProcedureAndFunctionDeclarationPartContext ctx) {
        String procedureName = ctx.procedureOrFunctionDeclaration().procedureDeclaration().identifier().getText();
        String[] procedureNames = procedureName.split("\\.");
        if (procedureNames.length == 1) {
            // normal procedure found
        } else {
            // find procedureNames[1] in procedureNames[0], and add to implementation stack
            DelphiClass delphiClass = classes.get(procedureNames[0]);
            ProcedureObject procedureObject = delphiClass.procedures.get(procedureNames[1]);

            delphiParser.StatementsContext statements = ctx.procedureOrFunctionDeclaration().procedureDeclaration().block().compoundStatement().statements();
            if (statements != null) {
                statements.statement().forEach(statementContext -> {
                    delphiParser.SimpleStatementContext simpleStatementContext = statementContext.unlabelledStatement().simpleStatement();
                    if (simpleStatementContext.assignmentStatement() != null) {
                        String variable = simpleStatementContext.assignmentStatement().variable().identifier().get(0).getText();
                        String expression = simpleStatementContext.assignmentStatement().expression().simpleExpression().term().signedFactor().factor().variable().identifier().get(0).getText();
                        ArrayList<String> statementList = new ArrayList<>();
                        statementList.add("ASSIGNMENT");
                        statementList.add(variable);
                        statementList.add(expression);
                        procedureObject.statements.add(statementList);
                    } else if (simpleStatementContext.procedureStatement() != null) {
                        if (Objects.equals(simpleStatementContext.procedureStatement().identifier().getText(), "Writeln")) {
                            ArrayList<String> statementList = new ArrayList<>();
                            statementList.add("PRINT");
                            if(simpleStatementContext.procedureStatement().parameterList().actualParameter() != null) {
                                for(int i = 0; i < simpleStatementContext.procedureStatement().parameterList().actualParameter().size(); i++) {
                                    delphiParser.FactorContext factorContext = simpleStatementContext.procedureStatement().parameterList().actualParameter().get(i).expression().simpleExpression().term().signedFactor().factor();
                                    if(factorContext.unsignedConstant() != null) {
                                        statementList.add(factorContext.unsignedConstant().string().getText());
                                    } else {
                                        statementList.add(factorContext.variable().identifier().get(0).getText());
                                    }
                                }
                            }
                            procedureObject.statements.add(statementList);
                        }
                    }
                });
            }
        }
        return super.visitProcedureAndFunctionDeclarationPart(ctx);
    }
    @Override
    public Object visitVariableDeclaration(delphiParser.VariableDeclarationContext ctx) {
        String varName = ctx.identifierList().identifier(0).getText();
        String typeName = ctx.type_().getText();
        DataTypes dataType = DataTypes.OBJECT;
        if (classes.containsKey(typeName)) {
            dataType = DataTypes.OBJECT;
        } else {
            try {
                dataType = DataTypes.fromString(typeName);
            } catch (Exception e) {
                System.out.println("Invalid datatype " + typeName);
            }
        }

        VariableObject variable = new VariableObject(varName, dataType, AccessIdentifiers.PUBLIC, null);
        variable.className = typeName;
        variables.put(varName, variable);

        if (classes.containsKey(typeName)) {
            // Create a new object instance
            DelphiObject obj = new DelphiObject(classes.get(typeName));
            objects.put(varName, obj);
        }
        return null;
    }

    @Override
    public Object visitCompoundStatement(delphiParser.CompoundStatementContext ctx) {
        if(ctx.getParent().getParent().getText().contains("program")) {
            // start execution
        List<delphiParser.StatementContext> statementContexts = ctx.statements().statement();
        for(delphiParser.StatementContext statementContext : statementContexts) {
            if (!statementContext.isEmpty() && !statementContext.getText().isEmpty()) {
                delphiParser.SimpleStatementContext simpleStatementContext = statementContext.unlabelledStatement().simpleStatement();
                if(simpleStatementContext.assignmentStatement() != null) {
                    visitAssignmentStatement(simpleStatementContext.assignmentStatement(), null);
                }
                if(simpleStatementContext.procedureStatement() != null) {
                    visitProcedureStatement(simpleStatementContext.procedureStatement(), null);
                }
            }
        }
            // end execution
        }
        return super.visitCompoundStatement(ctx);
    }

    public Object visitAssignmentStatement(delphiParser.AssignmentStatementContext ctx, Object object) {
        String variable = ctx.variable().identifier().get(0).getText();
        if(!variables.containsKey(variable)) {
            System.out.println("Variable does not exist: " + variable);
        }
        VariableObject obj = (VariableObject) variables.get(variable);
        delphiParser.ExpressionContext expressionContext = ctx.expression();

        List<Object> arguments = new ArrayList<>();
        List<delphiParser.ActualParameterContext> actualParameterContexts = expressionContext.simpleExpression().term().signedFactor().factor().functionDesignator().parameterList().actualParameter();
        for(int i = 0; i < actualParameterContexts.size(); i++) {
            String term = actualParameterContexts.get(i).expression().simpleExpression().term().signedFactor().factor().unsignedConstant().unsignedNumber().unsignedInteger().getText();
            delphiParser.FactorContext factorContext = actualParameterContexts.get(i).expression().simpleExpression().term().signedFactor().factor();
            if(factorContext.unsignedConstant() != null) {
                if(factorContext.unsignedConstant().unsignedNumber() != null) {
                    term = factorContext.unsignedConstant().unsignedNumber().unsignedInteger().getText();
                } else if (factorContext.unsignedConstant().string() != null) {
                    term = factorContext.unsignedConstant().string().getText();
                }
            } else if (factorContext.variable() != null) {
                String var = factorContext.variable().identifier().get(0).getText();
                if(!variables.containsKey(var)) {
                    System.out.println("Invalid variable:" + var);
                }
                term = variables.get(var).toString();
            }
            arguments.add(term);
        }

        String identifier = expressionContext.simpleExpression().term().signedFactor().factor().functionDesignator().identifier().getText();
        String[] identifierNames = identifier.split("\\.");
        if(identifierNames.length == 1) {
            if (variables.containsKey(identifierNames[0])) {
                if(obj.className != null && !obj.className.isEmpty()) {
                    VariableObject variableObject1 = (VariableObject) variables.get(identifierNames[0]);
                    obj.value = variableObject1.value;
                } else {
                    variables.put(variable, variables.get(identifierNames[0]));
                }
            } else {
                if(obj.className != null && !obj.className.isEmpty()) {
                    obj.value = identifierNames[0];
                }
            }
        } else {
            String className = identifierNames[0];
            String methodName = identifierNames[1];
            if(!classes.containsKey(className)) {
                System.out.println("Invalid class name: " + className);
            }

            DelphiClass delphiClass = classes.get(className);
            if (!delphiClass.constructors.containsKey(methodName) && !delphiClass.procedures.containsKey(methodName) && !delphiClass.destructors.containsKey(methodName)) {
                System.out.println("Invalid method name: " + methodName);
            }
            if(delphiClass.constructors.containsKey(methodName)) {
                ConstructorObject constructorObject = delphiClass.constructors.get(methodName);
                for (int i = constructorObject.statements.size() - 1; i >= 0; i--) {
                    List<String> statement = constructorObject.statements.get(i);
                    if(statement.get(0).equals("PRINT")) {
                        print(statement);
                    }
                    if(statement.get(0).equals("ASSIGNMENT")) {
                        String constructorVariable = statement.get(1);
                        DelphiObject delphiObject = objects.get(variable);
                        if(!delphiObject.instanceVariables.containsKey(constructorVariable)) {
                            System.out.println("Invalid variable: " + constructorVariable);
                        }
                        String expression = statement.get(2);
                        if(constructorObject.parameters.containsKey(expression)) {
                            ((VariableObject) delphiObject.instanceVariables.get(constructorVariable)).value = arguments.get(0);
                        } else {
                            ((VariableObject) delphiObject.instanceVariables.get(constructorVariable)).value = expression;
                        }
                    }
                }
            } else if(delphiClass.destructors.containsKey(methodName)) {
                DestructorObject destructorObject = delphiClass.destructors.get(methodName);
                for (int i = destructorObject.statements.size() - 1; i >= 0; i--) {
                    List<String> statement = destructorObject.statements.get(i);
                    if(statement.get(0).equals("PRINT")) {
                        print(statement);
                    }
                    if(statement.get(0).equals("ASSIGNMENT")) {
                        String destructorVariable = statement.get(1);
                        DelphiObject delphiObject = objects.get(variable);
                        if(!delphiObject.instanceVariables.containsKey(destructorVariable)) {
                            System.out.println("Invalid variable: " + destructorVariable);
                        }
                        String expression = statement.get(2);
                        if(destructorObject.parameters.containsKey(expression)) {
                            ((VariableObject) delphiObject.instanceVariables.get(destructorVariable)).value = arguments.get(0);
                        } else {
                            ((VariableObject) delphiObject.instanceVariables.get(destructorVariable)).value = expression;
                        }
                    }
                }
            } else {
                ProcedureObject procedureObject = delphiClass.procedures.get(methodName);
                for (int i = procedureObject.statements.size() - 1; i >= 0; i--) {
                    List<String> statement = procedureObject.statements.get(i);
                    if(statement.get(0).equals("PRINT")) {
                        print(statement);
                    }
                    if(statement.get(0).equals("ASSIGNMENT")) {
                        String procedureVariable = statement.get(1);
                        DelphiObject delphiObject = objects.get(variable);
                        if(!delphiObject.instanceVariables.containsKey(procedureVariable)) {
                            System.out.println("Invalid variable: " + procedureVariable);
                        }
                        String expression = statement.get(2);
                        if(procedureObject.variables.containsKey(expression)) {
                            ((VariableObject) delphiObject.instanceVariables.get(procedureVariable)).value = arguments.get(0);
                        } else {
                            ((VariableObject) delphiObject.instanceVariables.get(procedureVariable)).value = expression;
                        }
                    }
                }
            }
        }
        return null;
    }

    public Object visitProcedureStatement(delphiParser.ProcedureStatementContext ctx, Object object) {
        String variable = ctx.identifier().IDENT(0).getText();
        if(!variables.containsKey(variable)) {
            System.out.println("Variable does not exist: " + variable);
        }
        DelphiObject delphiObject = objects.get(variable);

        if(ctx.identifier().DOT() == null) {
            System.out.println("Invalid statement");
        }

        String identifier2 = ctx.identifier().IDENT(1).getText();

        DelphiClass delphiClass = classes.get(((VariableObject) variables.get(variable)).className);

        List<Object> arguments = new ArrayList<>();
        if(ctx.parameterList() != null) {
            List<delphiParser.ActualParameterContext> actualParameterContexts = ctx.parameterList().actualParameter();
            for (int i = 0; i < actualParameterContexts.size(); i++) {
                String term = actualParameterContexts.get(i).expression().simpleExpression().term().signedFactor().factor().unsignedConstant().unsignedNumber().unsignedInteger().getText();
                delphiParser.FactorContext factorContext = actualParameterContexts.get(i).expression().simpleExpression().term().signedFactor().factor();
                if(factorContext.unsignedConstant() != null) {
                    if(factorContext.unsignedConstant().unsignedNumber() != null) {
                        term = factorContext.unsignedConstant().unsignedNumber().unsignedInteger().getText();
                    } else if (factorContext.unsignedConstant().string() != null) {
                        term = factorContext.unsignedConstant().string().getText();
                    }
                } else if (factorContext.variable() != null) {
                    String var = factorContext.variable().identifier().get(0).getText();
                    if(!variables.containsKey(var)) {
                        System.out.println("Invalid variable:" + var);
                    }
                    term = ((VariableObject)variables.get(var)).toString();
                }
                arguments.add(term);
            }
        }
        if (!delphiClass.constructors.containsKey(identifier2) && !delphiClass.procedures.containsKey(identifier2) && !delphiClass.destructors.containsKey(identifier2)) {
            System.out.println("Invalid method name: " + identifier2);
        }

        if(delphiClass.constructors.containsKey(identifier2)) {
            ConstructorObject constructorObject = delphiClass.constructors.get(identifier2);
            for (int i = constructorObject.statements.size() - 1; i >= 0; i--) {
                List<String> statement = constructorObject.statements.get(i);
                if(statement.get(0).equals("PRINT")) {
                    print(statement);
                }
                if(statement.get(0).equals("ASSIGNMENT")) {
                    String constructorVariable = statement.get(1);
                    System.out.println(constructorVariable);
                    if(!delphiObject.instanceVariables.containsKey(constructorVariable)) {
                        System.out.println("Invalid variable: " + constructorVariable);
                    }
                    String expression = statement.get(2);
                    if(constructorObject.parameters.containsKey(expression)) {
                        ((VariableObject) delphiObject.instanceVariables.get(constructorVariable)).value = arguments.get(0);
                    } else {
                        ((VariableObject) delphiObject.instanceVariables.get(constructorVariable)).value = expression;
                    }
                }
            }
        } else if(delphiClass.destructors.containsKey(identifier2)) {
            DestructorObject destructorObject = delphiClass.destructors.get(identifier2);
            for (int i = destructorObject.statements.size() - 1; i >= 0; i--) {
                List<String> statement = destructorObject.statements.get(i);
                if(statement.get(0).equals("PRINT")) {
                    print(statement);
                }
                if(statement.get(0).equals("ASSIGNMENT")) {
                    String destructorVariable = statement.get(1);
                    System.out.println(destructorVariable);
                    if(!delphiObject.instanceVariables.containsKey(destructorVariable)) {
                        System.out.println("Invalid variable: " + destructorVariable);
                    }
                    String expression = statement.get(2);
                    if(destructorObject.parameters.containsKey(expression)) {
                        ((VariableObject) delphiObject.instanceVariables.get(destructorVariable)).value = arguments.get(0);
                    } else {
                        ((VariableObject) delphiObject.instanceVariables.get(destructorVariable)).value = expression;
                    }
                }
            }
        } else {
            ProcedureObject procedureObject = delphiClass.procedures.get(identifier2);
            for (int i = procedureObject.statements.size() - 1; i >= 0; i--) {
                List<String> statement = procedureObject.statements.get(i);
                if(statement.get(0).equals("PRINT")) {
                    print(statement);
                }
                if(statement.get(0).equals("ASSIGNMENT")) {
                    String procedureVariable = statement.get(1);
                    if(!delphiObject.instanceVariables.containsKey(procedureVariable)) {
                        System.out.println("Invalid variable: " + procedureVariable);
                    }
                    String expression = statement.get(2);
                    if(procedureObject.variables.containsKey(expression)) {
                        ((VariableObject) delphiObject.instanceVariables.get(procedureVariable)).value = arguments.get(0);
                    } else {
                        ((VariableObject) delphiObject.instanceVariables.get(procedureVariable)).value = expression;
                    }
                }
            }
        }

        return null;
    }

    public static void print(List<String> statement) {
        String expression = statement.get(1);
        System.out.println(expression);
    }

    public static void main(String[] args) throws IOException {
        if(args.length == 0) {
            System.out.println("Enter file name to parse");
            System.exit(1);
        }
        String filePath = "TestCases/";
        String fileName = args[0];

        String content = Files.readString(Path.of(filePath + fileName), StandardCharsets.UTF_8);

        ANTLRInputStream input = new ANTLRInputStream(content);
        delphiLexer delphiLexer = new delphiLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(delphiLexer);
        delphiParser delphiParser = new delphiParser(tokens);

        ParseTree tree = delphiParser.program();
        DelphiInterpreter delphiInterpreter = new DelphiInterpreter();
        System.out.println("-------DELPHI EXECUTION BEGINS-------");
        Object result = delphiInterpreter.visit(tree);
        System.out.println("-------DELPHI EXECUTION ENDS-------");

        System.out.println("\n\nPRINT ALL NORMAL VARIABLES PLUS OBJECTS:");
        variables.forEach((k, v) -> {
            if(v instanceof VariableObject variableObject) {
                System.out.println("Name: " + variableObject.name + ", Datatype: " + variableObject.datatype + ", Access Identifier: " + variableObject.visibility + ", Value: " + variableObject.value);
                if (((VariableObject) v).className != null) {
                    DelphiObject delphiObject = objects.get(k);
                    delphiObject.instanceVariables.forEach((k1, v1) -> {
                        System.out.println("Value of " + k1 + ": " + ((VariableObject) v1).value);
                    });
                }
            }

        });

        System.out.println("PRINT ALL CLASSES:");
        classes.forEach((k, v) -> {
            System.out.println(v.name);
            System.out.println("Variables: ->");
            v.variables.forEach((k1, v1) -> {
                System.out.println("Name: " + v1.name + ", Datatype: " + v1.datatype + ", Access Identifier: " + v1.visibility + ", Value: " + v1.value);
            });
            System.out.println("Constructors: ->");
            v.constructors.forEach((k1, v1) -> {
                System.out.println(k1 + ", " + v1.visibility);
                v1.parameters.forEach((k2, v2) -> {
                    System.out.println("Name: " + v2.name + ", Datatype: " + v2.datatype + ", Access Identifier: " + v2.visibility + ", Value: " + v2.value);
                });
            });
            System.out.println("Destructors: ->");
            v.destructors.forEach((k1, v1) -> {
                System.out.println(k1 + ", " + v1.visibility);
                v1.parameters.forEach((k2, v2) -> {
                    System.out.println("Name: " + v2.name + ", Datatype: " + v2.datatype + ", Access Identifier: " + v2.visibility + ", Value: " + v2.value);
                });
            });
            System.out.println("Procedures: ->");
            v.procedures.forEach((k1, v1) -> {
                System.out.println(k1 + ": " + v1.visibility);
                v1.variables.forEach((k2, v2) -> {
                    System.out.println("Name: " + v2.name + ", Datatype: " + v2.datatype + ", Access Identifier: " + v2.visibility + ", Value: " + v2.value);
                });
            });
        });
    }
}
